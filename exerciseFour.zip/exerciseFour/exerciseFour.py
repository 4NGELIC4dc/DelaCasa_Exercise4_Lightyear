light=3*10**8
distance=365*24*60**2
year=(light*distance)
print("Light travels", year ,"meters in a year")